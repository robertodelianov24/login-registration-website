<?php

session_start();

$con = mysqli_connect('localhost', 'roberto', 'roberto24');
if(!$con){
    echo 'Can not connect to database! Try again later.';
}
if(!mysqli_select_db($con,'RegistratedUsers')){
    echo 'Can not find the database! Try again later.';
}

$username = mysqli_real_escape_string($con,$_POST['username']);
$password = mysqli_real_escape_string($con,$_POST['pass']);

$sql = "SELECT * FROM Registrated WHERE username = '$username' AND pass = '$password'";
$masiv_sql = mysqli_query($con,$sql);
$num = mysqli_num_rows($masiv_sql);
if($num == 1){
    $_SESSION['username'] = $username;
    header('location:http://localhost/website2/mainIn.php');
} else {
    header('location:http://localhost/website2/Registration/errorLogin.html');
}

?>