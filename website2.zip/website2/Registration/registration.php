<?php

$conn = mysqli_connect('localhost', 'roberto', 'roberto24');
    if(!$conn){
        echo 'Can not connect to database! Try again later.';
    }
    if(!mysqli_select_db($conn,'RegistratedUsers')){
        echo 'Can not find the database! Try again later.';
    }

$username = mysqli_real_escape_string($conn,$_POST['username']);
$password = mysqli_real_escape_string($conn,$_POST['pass']);
$email = mysqli_real_escape_string($conn,$_POST['email']);

$sqlcheck = "SELECT * FROM Registrated WHERE username = '$username' OR email = '$email' LIMIT 1";
$result = mysqli_query($conn, $sqlcheck);
$user = mysqli_fetch_assoc($result);
if ($user) { 
if ($user['username'] === $username) {
    header('location:http://localhost/website2/Registration/errorRegistration.html');
    die();
    }
if ($user['email'] === $email) {
    header('location:http://localhost/website2/Registration/errorRegistration.html');
    die();
    }
}

$sql = "INSERT INTO Registrated (username,pass,email) VALUES('$username','$password','$email')";
if(!mysqli_query($conn,$sql)){
    echo 'Something went wrong! Try again!!!';
}else{
    header('location:http://localhost/website2/Registration/successfullRegistration.html');
}


?>