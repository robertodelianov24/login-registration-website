<!DOCTYPE html>

<html>


<head>

    <title>Welcome</title>
    <link rel="shortcut icon" href="24.png">
    <link rel="stylesheet" href="http://localhost/website2/css/main.css"> 

</head>




<center><body>
    <h style="font-size: 130px;"><b>24</b></h>
    <div id="registration">
        <h1 align=center>REGISTRATION</h1></br>
        <form id="formregistration" action="http://localhost/website2/Registration/registration.php" method="POST">
            <table>
                <tr>
                    <td>
                        <b>Username:</b>
                    </td>
                    <td>
                        <input type="text" name="username" required>
                    </td>
                    </tr>
                    <tr>
                    <td>
                        <b>Password:</b>
                    </td>
                    <td>
                        <input type="password" name="pass" required>
                    </td>
                    </tr>
                    <tr>
                    <td>
                        <b>Email:</b>
                    </td>
                    <td>
                        <input type="text" name="email" required>
                    </td>
                    </tr>
                    <tr>
                    <td>
                        <input id="signUp" onclick="ValidateEmail()" type="submit" name="signUp" value="sign Up" >
                    </td>
                </tr>
            </table>
        </form>
    </div>
    <div id="login">
        <h2 align=center>LOGIN</h2></br>
        <form id="formlogin" action="http://localhost/website2/Registration/login.php" method="POST">
            <table>
                <tr>
                    <td>
                        <b>Username:</b>
                    </td>
                    <td>
                        <input type="text" name="username" required>
                    </td>
                    </tr>
                    <tr>
                    <td>
                        <b>Password:</b>
                    </td>
                    <td>
                        <input type="password" name="pass" required>
                    </tr>
                    <tr>
                    <td>
                        <input id="signIn" type="submit" name="signIn" value="sign In" >
                    </td>
                </tr>
            </table>
        </form>
    </div>


    <script>
        //signUp button style
        var signUp = document.getElementById("signUp");
        signUp.style.border = "2px solid black";
        signUp.style.backgroundColor = "rgba(19, 0, 0, 0.486)"
        signUp.style.color = "red";
        signUp.style.width = "100px";
        signUp.style.height = "50px";
        signUp.style.borderRadius = "30%";
        signUp.style.fontSize = "20px";
        signUp.style.fontStyle = "italic";

        //signIn button style
        var signIn = document.getElementById("signIn");
        signIn.style.border = "2px solid black";
        signIn.style.backgroundColor = "rgba(19, 0, 0, 0.486)"
        signIn.style.color = "red";
        signIn.style.width = "100px";
        signIn.style.height = "50px";
        signIn.style.borderRadius = "30%";
        signIn.style.fontSize = "20px";
        signIn.style.fontStyle = "italic";

        //check Registration
        var formReg = document.getElementById("formregistration");
        var email = document.getElementsByName("email");
        function ValidateEmail() {
            if (/^(([^<>()\[\]\\.,;:@"\x00-\x20\x7F]|\\.)+|("""([^\x0A\x0D"\\]|\\\\)+"""))@(([a-z]|#\d+?)([a-z0-9-]|#\d+?)*([a-z0-9]|#\d+?)\.)+([a-z]{2,4})$/i.test(formReg.email.value)){
            return (true)
            }else{
                alert("You have entered an invalid email address!")
                formReg.action = "http://localhost/website2/main.php";
                }
            }
    </script>



</body></center>






</html