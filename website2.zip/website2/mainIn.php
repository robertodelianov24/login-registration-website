<?php 
session_start();
if (!isset($_SESSION['username'])) {
    header('location: http://localhost/website2/main.php');
}
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: http://localhost/website2/main.php");
}
?>
<!DOCTYPE html>

<html>


<head>

    <title>Welcome,</title>
    <link rel="stylesheet" href="http://localhost/website2/css/mainIn.css">

</head>


<body>

<center><h style="font-size: 100px;"><b>24</b></h></center>

        <div id="mainMenu">
            <div id="plusMenu">|||</div>
            <div id="string">Hello, <?php echo $_SESSION['username'] ?></div>
            <div id="logout"> <a href="mainIn.php?logout='1'" style="color: red;">logout</a> </div>
        </div>

        <center><div id="menu">
            <p>
                <button1 id="button1" class="buttons">About us</button1>
                <button2 id="button2" class="buttons">Games</button2>
                <button3 id="button3" class="buttons">News</button3>
                <button4 id="button4" class="buttons">Products</button4>
                <button5 id="button5" class="buttons">Contacts</button5>
            </p>
        </div></center>
        
        <script>
            var button1 = document.getElementById("button1");
            function hoverButton(e){
                target = e.target;
                switch(e.type){
                    case "mouseover":
                        if(target.className == "buttons"){
                        target.className = "button1Class";
                    }
                    break;
                    case "mouseout":
                        if(target.className == "button1Class"){
                        target.className = "buttons";
                    }
                    break;
                }   
            }
            document.addEventListener("mouseover",hoverButton);
            document.addEventListener("mouseout",hoverButton);
        </script>

</body>






</html